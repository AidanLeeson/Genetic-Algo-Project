from Schedule_Class import *
import random
import numpy as np

def generate_random_schedule(rooms, facilitators, activity_names, expected_enrollments):
    schedule = Schedule()

    # Shuffle lists to ensure randomness
    random.shuffle(rooms)
    random.shuffle(facilitators)
    random.shuffle(activity_names)

    # Keep track of facilitator loads
    facilitator_loads = {facilitator.name: 0 for facilitator in facilitators}

    for activity_name in activity_names:
        # Choose a random room and facilitator for the activity
        room = random.choice(rooms)
        facilitator = random.choice([f for f in facilitators if facilitator_loads[f.name] < f.max_activities])

        # Increment the load for the selected facilitator
        facilitator_loads[facilitator.name] += 1

        # Create an Activity object
        activity = Activity(
            name=activity_name,
            room=room,
            facilitator=facilitator,
            expected_enrollment=expected_enrollments.get(activity_name, 0)
        )

        # Add the activity to the schedule
        schedule.add_activity(activity)

        # Optionally, check for facilitator load here and remove from list if maxed out
        facilitators = [f for f in facilitators if facilitator_loads[f.name] < f.max_activities]

    return schedule

def softmax_selection(population, fitness_scores, temperature=1.0):
    # Adjust fitness scores by temperature
    scaled_fitness = np.array(fitness_scores) / temperature
    
    # Compute softmax probabilities
    max_fitness = np.max(scaled_fitness)  # for numerical stability
    exp_scores = np.exp(scaled_fitness - max_fitness)
    probabilities = exp_scores / np.sum(exp_scores)
    
    # Select individual based on computed probabilities
    selected_index = np.random.choice(len(population), p=probabilities)
    return population[selected_index]

def crossover(parent1, parent2):
    crossover_index = random.randint(1, len(parent1.activities) - 2)

    # Create a new list of activities for the child
    # First half from parent1, second half from parent2
    child_activities = parent1.activities[:crossover_index] + parent2.activities[crossover_index:]

    # Now, construct the new child Schedule with the combined activities
    child_schedule = Schedule()
    child_schedule.activities = child_activities

    return child_schedule

def mutate(schedule, mutation_rate, times, rooms, facilitators):
    # Go through each activity in the schedule
    for activity in schedule.activities:
        if random.random() < mutation_rate:
            # Randomly choose an attribute to mutate: time, room, or facilitator
            attribute_to_mutate = random.choice(['time', 'room', 'facilitator'])
            
            # Mutate the chosen attribute
            if attribute_to_mutate == 'time':
                # Assign a new random time slot
                activity.time = random.choice(times)
            elif attribute_to_mutate == 'room':
                # Assign a new random room
                activity.room = random.choice(rooms)
            elif attribute_to_mutate == 'facilitator':
                # Assign a new random facilitator
                activity.facilitator = random.choice(facilitators)
                

def Main():
    roomList = [Room("Slater303", 45),
                Room("Roman216",30),
                Room("Loft206",75),Room("Roman201",50),
                Room("Loft310",108),Room("Beach201",60),
                Room("Beach301",75),Room("Logos325",450),
                Room("Frank119",60)]
    facilitatorList = [Facilitator("Lock",["SLA100A","SLA100B","SLA191A","SLA191B","SLA291"],5),
                       Facilitator("Glen",["SLA100A","SLA100B","SLA191A","SLA191B","SLA291"],7),
                       Facilitator("Banks",["SLA100A","SLA100B","SLA191A","SLA191B","SLA201","SLA291","SLA303","SLA304"],9),
                       Facilitator("Richard",[],9),
                       Facilitator("Shaw",["SLA201","SLA449","SLA451"],5),
                       Facilitator("Singer",["SLA291","SLA394","SLA449","SLA451"],7),
                       Facilitator("Uther",[],3),
                       Facilitator("Tyler",["SLA304","SLA394","SLA449","SLA451"],5),
                       Facilitator("Numen",[],8),
                       Facilitator("Zeldin",["SLA100A","SLA100B","SLA191A","SLA191B","SLA201","SLA291","SLA303"],10)]
    activities = ["SLA100A","SLA100B","SLA191A","SLA191B","SLA201","SLA291","SLA303","SLA304","SLA394","SLA449","SLA451"]
    times = ["10 AM","11 AM","12 PM","1 PM","2 PM","3 PM"]
    expectedEnrollment = {"SLA100A": 50, "SLA100B": 50, "SLA191A": 50, "SLA191B": 50, "SLA201": 50, "SLA291": 50, "SLA303": 60, "SLA304": 25, "SLA394": 20, "SLA449": 60,"SLA451": 100}
    
    scheduleList = []
    for num in range(500):
        scheduleList.append(generate_random_schedule(roomList,facilitatorList,activities,expectedEnrollment))

    new_gen = []
    fitness_history = []
    pop_size = len(scheduleList)
   
    fitnessScores = []
    for sched in scheduleList:
        fitnessScores.append(sched.calculate_fitness())

    for generation in range(300):
        avg_fitness = sum(fitnessScores)/len(fitnessScores)
        fitness_history.append(avg_fitness)
        if generation >= 100:
            improvement = (avg_fitness - fitness_history[generation - 100])/fitness_history[generation - 100]
            if improvement < 0.01:
               print(scheduleList[fitnessScores.index(max(fitnessScores))])
               break
        parent1 = softmax_selection(scheduleList, fitnessScores)
        parent2 = softmax_selection(scheduleList, fitnessScores)
        child = crossover(parent1,parent2)
        mutate(child, 0.01, times,roomList,facilitatorList)
        new_gen.append(child)
    
    
    
    

