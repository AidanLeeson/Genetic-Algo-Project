class Activity:
    def __init__(self, name, room, facilitator, expected_enrollment):
        self.name = name
        self.room = room
        self.facilitator = facilitator
        self.expected_enrollment = expected_enrollment

     def is_preferred_facilitator(self):
        # Check if the assigned facilitator is preferred for this activity
        return self.facilitator.name in self.preferred_facilitators

    def has_sufficient_capacity(self):
        # Check if the room has sufficient capacity for the expected enrollment
        return self.room.capacity >= self.expected_enrollment

class Room:
    def __init__(self, name, capacity):
        self.name = name
        self.capacity = capacity

class Facilitator:
    def __init__(self, name, preferred_activities, max_activities):
        self.name = name
        self.preferred_activities = preferred_activities  # List of preferred activity names
        self.max_activities = max_activities
        self.assigned_activities = []

    def assign_activity(self, activity):
        if len(self.assigned_activities) < self.max_activities:
            self.assigned_activities.append(activity)
            return True
        return False

    def is_preferred_for(self, activity):
        return activity.name in self.preferred_activities

    def can_oversee(self, activity):
        # Assuming all facilitators can oversee all activities for simplicity
        return True

class Schedule:
    def __init__(self):
        self.activities = []

    def add_activity(self, activity):
        self.activities.append(activity)

    def get_sections(self, activity_name):
        return [activity for activity in self.activities if activity.name == activity_name]

    def calculate_fitness(self):
        fitness_score = 0
        facilitator_loads = {}

        # Example of conflict checking
        for activity in self.activities:
            if not activity.has_sufficient_capacity():
                fitness_score -= 1  # Apply penalty for insufficient room capacity

            # Facilitator-related evaluations
            facilitator = activity.facilitator
            if facilitator.is_preferred_for(activity):
                fitness_score += 0.5
            elif facilitator.can_oversee(activity):
                fitness_score += 0.2
            else:
                fitness_score -= 0.1

            # Update facilitator load
            if facilitator.name in facilitator_loads:
                facilitator_loads[facilitator.name] += 1
            else:
                facilitator_loads[facilitator.name] = 1

        # Apply penalties or rewards based on facilitator loads
        for facilitator_name, load in facilitator_loads.items():
            if load > facilitator.max_activities:
                fitness_score -= 0.5 * (load - facilitator.max_activities)  # Overload penalty
            else:
                fitness_score += 0.2 * load  # Ideal load reward

        # Specific checks for "SLA 101" and "SLA 191" could go here

        return fitness_score

    
