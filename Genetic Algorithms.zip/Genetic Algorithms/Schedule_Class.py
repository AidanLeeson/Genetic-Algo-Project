class Activity:
    def __init__(self, name, room, facilitator, expected_enrollment):
        self.name = name
        self.room = room
        self.facilitator = facilitator
        self.expected_enrollment = expected_enrollment

    def __str__(self):
        return f'Activity({self.name}, {self.facilitator})'

    def __repr__(self):
        return f'Activity(name="{self.name}", facilitator="{self.facilitator}")'

    def is_preferred_facilitator(self):
        # Check if the assigned facilitator is preferred for this activity
        return self.facilitator.name in self.preferred_facilitators

    def has_sufficient_capacity(self):
        # Check if the room has sufficient capacity for the expected enrollment
        return self.room.capacity >= self.expected_enrollment

class Room:
    def __init__(self, name, capacity):
        self.name = name
        self.capacity = capacity

class Facilitator:
    def __init__(self, name, preferred_activities, max_activities):
        self.name = name
        self.preferred_activities = preferred_activities  # List of preferred activity names
        self.max_activities = max_activities
        self.assigned_activities = []

    def assign_activity(self, activity):
        if len(self.assigned_activities) < self.max_activities:
            self.assigned_activities.append(activity)
            return True
        return False

    def is_preferred_for(self, activity):
        return activity.name in self.preferred_activities

    def can_oversee(self, activity):
        # Assuming all facilitators can oversee all activities for simplicity
        return True

class Schedule:
    def __init__(self):
        self.activities = []

    def __str__(self):
        f = open("BestAlgo.txt","w+")
        for activity in self.activities:
            f.write(f'Activity: {activity.name} Room: {activity.room.name} Facilitator: {activity.facilitator.name}\n')
        f.close()
        return f'Schedule with {len(self.activities)} activities'

    def __repr__(self):
        activities_repr = ", ".join(repr(activity) for activity in self.activities)
        return f'Schedule({activities_repr})'

    def add_activity(self, activity):
        self.activities.append(activity)

    def get_sections(self, activity_name):
        return [activity for activity in self.activities if activity.name == activity_name]

    def calculate_fitness(self):
        fitness_score = 0
        facilitator_loads = {}

        # Example of conflict checking
        for activity in self.activities:
            if not activity.has_sufficient_capacity():
                fitness_score -= 1  # Apply penalty for insufficient room capacity

            # Facilitator-related evaluations
            facilitator = activity.facilitator
            if facilitator.is_preferred_for(activity):
                fitness_score += 0.5
            elif facilitator.can_oversee(activity):
                fitness_score += 0.2
            else:
                fitness_score -= 0.1

            # Update facilitator load
            if facilitator.name in facilitator_loads:
                facilitator_loads[facilitator.name] += 1
            else:
                facilitator_loads[facilitator.name] = 1

        # Apply penalties or rewards based on facilitator loads
        for facilitator_name, load in facilitator_loads.items():
            if load > facilitator.max_activities:
                fitness_score -= 0.5 * (load - facilitator.max_activities)  # Overload penalty
            else:
                fitness_score += 0.2 * load  # Ideal load reward

        sla_101_sections = [activity for activity in self.activities if activity.name == "SLA 101"]
        sla_191_sections = [activity for activity in self.activities if activity.name == "SLA 191"]

        # Check SLA 101 sections
        if len(sla_101_sections) == 2:
            if abs(sla_101_sections[0].time - sla_101_sections[1].time) > 4:
                fitness_score += 0.5
            elif sla_101_sections[0].time == sla_101_sections[1].time:
                fitness_score -= 0.5

        # Check SLA 191 sections
        if len(sla_191_sections) == 2:
            if abs(sla_191_sections[0].time - sla_191_sections[1].time) > 4:
                fitness_score += 0.5
            elif sla_191_sections[0].time == sla_191_sections[1].time:
                fitness_score -= 0.5

        # Check consecutive time slots for SLA 101 and SLA 191
        for sla_101_section in sla_101_sections:
            for sla_191_section in sla_191_sections:
                if abs(sla_101_section.time - sla_191_section.time) == 1:  # Consecutive time slots
                    fitness_score += 0.5
                    if ((sla_101_section.room in ['Roman', 'Beach']) != (sla_191_section.room in ['Roman', 'Beach'])):
                        fitness_score -= 0.4
                elif abs(sla_101_section.time - sla_191_section.time) == 2:  # Separated by 1 hour
                    fitness_score += 0.25
                elif sla_101_section.time == sla_191_section.time:  # Same time slot
                    fitness_score -= 0.25


        return fitness_score

    
